require 'test_helper'

class CreateSecureRandomTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
