DROP TABLE cattoys;
DROP TABLE cats;
DROP TABLE toys;


CREATE TABLE cats (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    color VARCHAR(255),
    breed VARCHAR(255) 
);

CREATE TABLE toys (
    id SERIAL PRIMARY KEY,
    color VARCHAR(255),
    price INTEGER,
    name VARCHAR(255)
);

CREATE TABLE cattoys(
  id SERIAL PRIMARY KEY,
  cat_id INTEGER,
  toy_id INTEGER,

  FOREIGN KEY (cat_id) REFERENCES cats(id),
  FOREIGN KEY (toy_id) REFERENCES toys(id)
);

INSERT INTO cats (name, color, breed)
  VALUES ('Fluffy', 'White', 'Whitecat');
INSERT INTO cats (name, color, breed)
  VALUES ('Whiskers', 'Black', 'Blackcat');
INSERT INTO cats (name, color, breed)
  VALUES ('Bandit', 'Gray', 'Tabby');
INSERT INTO cats (name, color, breed)
  VALUES ('Oscar', 'Yellow', 'Poolcat');
INSERT INTO cats (name, color, breed)  
  VALUES ('Mike', 'Purple', 'Drycat');
INSERT INTO toys (color, price, name)
  VALUES ('Blue', 2, 'Boxing_Toy');
INSERT INTO toys (color, price, name)
  VALUES ('Red', 1, 'Chew_Toy');
INSERT INTO toys (color, price, name)
  VALUES ('Yellow', 5, 'Scratch_Toy');
INSERT INTO toys (color, price, name)
  VALUES ('Purple', 3, 'Fun_Toy');
INSERT INTO toys (color, price, name)
  VALUES ('Green', 10, 'Bounce_Toy');
INSERT INTO cattoys (cat_id, toy_id)
  VALUES (1, 1);
INSERT INTO cattoys (cat_id, toy_id)
  VALUES (2, 2);
INSERT INTO cattoys (cat_id, toy_id)
  VALUES (3, 3);
INSERT INTO cattoys (cat_id, toy_id)
  VALUES (4, 4);
INSERT INTO cattoys (cat_id, toy_id)
  VALUES (5, 5);