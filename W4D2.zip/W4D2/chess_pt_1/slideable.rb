module Slideable

  HORIZONTAL_DIRS = []
  DIAGONAL_DIRS = []



end